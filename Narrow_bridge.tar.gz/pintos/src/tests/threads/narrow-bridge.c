
/* File for 'narrow_bridge' task implementation.  
   SPbSTU, IBKS, 2017 */

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"
#include "devices/timer.h"

struct semaphore cars_left, cars_right, emergency_left, emergency_right;
int count_cars_left = 0, count_cars_right = 0, count_emergency_left = 0, count_emergency_right = 0, count_cars = 0, count_emergency = 0;
unsigned int current_dir = 1;


// Called before test. Can initialize some synchronization objects.
void narrow_bridge_init(void){
  sema_init(&cars_left, 0);
  sema_init(&cars_right, 0);
  sema_init(&emergency_left, 0);
  sema_init(&emergency_right, 0);
}

void arrive_bridge(enum car_priority prio, enum car_direction dir){
  if (prio == car_emergency){
    if (dir == dir_left){
      if (count_cars == 0){
	count_cars++;
	current_dir = dir;
	return;
      }
      else if(count_cars == 1 && current_dir == dir_left){
	count_cars++;
	return;
      }
      count_emergency_left++;
      sema_down(&emergency_left);
      current_dir = dir;
    }
    else{
      if (count_cars == 0){
	count_cars++;
	current_dir = dir;
	return;
      }
      else if(count_cars == 1 && current_dir == dir_right){
	count_cars++;
	return;
      }
      count_emergency_right++;
      sema_down(&emergency_right);
      current_dir = dir;
    }
  }
  else{
    if (dir == dir_left){
      if (count_cars == 0){
	count_cars++;
	current_dir = dir;
	return;
      }
      else if(count_cars == 1 && current_dir == dir_left){
        count_cars++;
	return;
      }
      count_cars_left++;
      timer_sleep(1);
      sema_down(&cars_left);
      current_dir = dir;
    }
    else{
      if (count_cars == 0){
	count_cars++;
	current_dir = dir;
	return;
      }
      else if(count_cars == 1 && current_dir == dir_right){
        count_cars++;
	return;
      }
      count_cars_right++;
      timer_sleep(1);
      sema_down(&cars_right);
      current_dir = dir;
    }
  }
}

void exit_bridge(enum car_priority prio, enum car_direction dir UNUSED){
  //msg("prio: %d   em_left: %d   em_right: %d   left: %d   right: %d   cars: %d", prio, count_emergency_left, count_emergency_right, count_cars_left, count_cars_right, count_cars);

  count_cars--;
  //else if (count_cars < 0) count_cars++;
  if (count_cars == 1) return;
  if (count_emergency_left > 0 || count_emergency_right > 0){
    //msg("count_left: %d, count_right: %d", count_emergency_left, count_emergency_right);
    if (count_emergency_left > 0){
      sema_up(&emergency_left);
      count_cars++;
      count_emergency_left--;
      if (count_emergency_left > 0){
        sema_up(&emergency_left);
	count_cars++;
        count_emergency_left--;
      }
      else if (count_emergency_left == 0 && count_cars_left > 0){
        sema_up(&cars_left);
	count_cars++;
        count_cars_left--;
      }
    }
    else if (count_emergency_right > 0){
      sema_up(&emergency_right);
      count_cars++;
      count_emergency_right--;
      if (count_emergency_right > 0){
        sema_up(&emergency_right);
	count_cars++;
        count_emergency_right--;
      }
      else if(count_emergency_right == 0 && count_cars_right > 0){
	sema_up(&cars_right);
	count_cars++;
	count_cars_right--;
      }
    }
  }

  else{
    //msg("in else");
    //msg("prio: %d   em_left: %d   em_right: %d   left: %d   right: %d   cars: %d", prio, count_emergency_left, count_emergency_right, count_cars_left, count_cars_right, count_cars);
    if (count_cars_left > 0){
      sema_up(&cars_left);
      count_cars++;
      count_cars_left--;
      if (count_cars_left > 0){
        sema_up(&cars_left);
	count_cars++;
        count_cars_left--;
      }
    }
    //msg("ccr %d, cr %d", count_cars_right, count_cars);
    else if (count_cars_right > 0){
      sema_up(&cars_right);
      count_cars++;
      count_cars_right--;
      if (count_cars_right > 0){
        sema_up(&cars_right);
	count_cars++;
        count_cars_right--;
      }
    }
  //}
  }
}
